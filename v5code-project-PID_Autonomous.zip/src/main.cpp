/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Amar                                             */
/*    Created:      Wed Jan 25 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// LeftMotors           motor_group   1, 2            
// RightMotors          motor_group   3, 21           
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

void pre_auton(void) {  
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
}



//PID EXPLANATION: This code is for driving and turning accurately. When the bot swerves right or left, our PID will correct
//and add power on the other side to correct the path. The turn will prevent overshooting and undershooting by finding the
//difference of the error and adding it to the motor power. The left and right motors will have the same power while driving 
//forward and the opposite power while turning.


//PID Settings
const double kP = 1.0;
const double kI = 0.0;
const double kD = 0.0;

const double turnkP = 1.0; 
const double turnkI = 0.0; 
const double turnkD = 0.0; 

//Autonomous Variables
int desiredValue = 200;
int turnDesiredValue;

int error; //SensorValue - DesiredValue : Position
int preErr = 0; //Position 20 ms ago
int derivative; // error - prevError : Speed
int totalError;

int turnError; // sensor - desired
int turnPrevError = 0; // pos from last loop
int turnDerivative; // diference bettween error and prev error : Speed
int turnTotalError = 0; // Integral Total error = totalError + error, every loop


//Variables for use in Code (add false to user control and set true for autonomous)
bool enableDrivePID = true;

int drivePid(){

  while(enableDrivePID){

    //Define the motor position
    int LeftMotorsPos = LeftMotors.position(degrees);
    int RightMotorsPos = RightMotors.position(degrees);



    //////BELOW IS THE FORWARD PID (DRIVE)


    //Motor Average
    int MeanPos = (LeftMotorsPos + RightMotorsPos)/2;

    //Potential
    error = MeanPos - desiredValue;


    //Derivative
    derivative = error - preErr;

    //Integral
    totalError += error;
    double forwardmotorPower = (error * kP + derivative * kD + totalError * kI);



    /////BELOW IS PID TURNS (INPROGRESS)

     int turnDifference = LeftMotorsPos - RightMotorsPos;

     turnError = turnDesiredValue - turnDifference;

     turnDerivative = turnError - turnPrevError;

     turnTotalError += turnError;
    
     double turnMotorPower = (error * turnkP + derivative * turnkD + totalError * turnkI);

      LeftMotors.spin(forward, forwardmotorPower + turnMotorPower, voltageUnits::volt);
      RightMotors.spin(forward, forwardmotorPower - turnMotorPower, voltageUnits::volt);


    //code
    preErr = error;
    turnPrevError = turnError;

    vex::task::sleep(20);
    
  }

  return 1;
}